import React from 'react';

const Timetable = () => {
    return (
        <div style={{ textAlign: 'center' }}>
            <h1>Timetable</h1>
            <p>Time table is Scheduled after Holidays</p>
        </div>
    );
};

export default Timetable;