import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faChartLine, faBookOpen, faGraduationCap } from '@fortawesome/free-solid-svg-icons';

const About = () => {
    return (
        <div className="container-fluid mt-5">
            <div className="row">
                <div className="col-4">
                    <div className="text-center p-4 bg-light rounded shadow">
                        <FontAwesomeIcon icon={faChartLine} size="3x" className="text-primary mb-3" />
                        <h2>Check Attendance</h2>
                        <p>Monitor your attendance records and stay on top of your commitments.</p>
                    </div>
                </div>
                <div className="col-4">
                    <div className="text-center p-4 bg-light rounded shadow">
                        <FontAwesomeIcon icon={faBookOpen} size="3x" className="text-primary mb-3" />
                        <h2>View Internals</h2>
                        <p>Access your internal marks and track your academic progress.</p>
                    </div>
                </div>
                <div className="col-4">
                    <div className="text-center p-4 bg-light rounded shadow">
                        <FontAwesomeIcon icon={faGraduationCap} size="3x" className="text-primary mb-3" />
                        <h2>Manage Credits</h2>
                        <p>Keep track of your credit subjects and plan your academic journey.</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default About;