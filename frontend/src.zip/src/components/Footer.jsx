// src/components/Footer.js
import React from 'react';
import { colors } from './colors';

const Footer = () => {
  return (
    <footer style={styles.footer}>
      <p style={styles.text}>© 2025 Feb 1st Student Management Portal. All rights reserved.</p>
    </footer>
  );
};

const styles = {
  footer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    padding: '20px',
    backgroundColor: colors.primary,
    color: colors.secondary,
    marginTop: 'auto',
  },
  text: {
    fontSize: '16px',
  },
};

export default Footer;