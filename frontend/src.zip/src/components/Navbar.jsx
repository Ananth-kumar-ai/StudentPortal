import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { colors } from './colors';

const Navbar = ({ auth, setAuth }) => {
  const [showDropdown, setShowDropdown] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setAuth({ isAuthenticated: false, user: null }); // 🔥 Update global auth state
    navigate('/');
  };

  return (
    <div style={styles.container}>
      <nav style={styles.nav}>
        <div style={styles.logo}>
          <Link to="/" style={styles.link}>Student Portal</Link>
        </div>
        <div style={styles.navLinks}>
          <Link to="/att" style={styles.link}>Attendance</Link>
          <Link to="/int" style={styles.link}>Internals</Link>
          <Link to="/Ann" style={styles.link}>Announcements</Link>
          <Link to="/Time" style={styles.link}>Timetable</Link>
        </div>
        <div style={styles.authLinks}>
          {auth.isAuthenticated ? (
            <div
              style={styles.profileContainer}
              onMouseEnter={() => setShowDropdown(true)}
              onMouseLeave={() => setShowDropdown(false)}
            >
              <div style={styles.profile}>
                <span style={styles.profileText}>{auth.user?.Regno}</span>
              </div>
              {showDropdown && (
                <div style={styles.dropdown}>
                  <p>Email: {auth.user?.email}</p>
                  <button onClick={handleLogout} style={styles.logoutButton}>Log Out</button>
                </div>
              )}
            </div>
          ) : (
            <Link to="/login" style={styles.loginButton}>Log In</Link>
          )}
        </div>
      </nav>
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    justifyContent: 'center',
    padding: '10px 0',
  },
  nav: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '10px 20px',
    backgroundColor: colors.primary,
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    borderRadius: '20px',
    width: '80%',
    maxWidth: '1200px',
  },
  logo: {
    fontSize: '24px',
    fontWeight: 'bold',
    color: colors.secondary,
  },
  navLinks: {
    display: 'flex',
    gap: '20px',
  },
  link: {
    color: colors.secondary,
    textDecoration: 'none',
    fontSize: '16px',
    transition: 'color 0.3s ease',
  },
  authLinks: {
    display: 'flex',
    gap: '20px',
  },
  loginButton: {
    padding: '8px 16px',
    backgroundColor: colors.accent,
    color: colors.secondary,
    textDecoration: 'none',
    borderRadius: '4px',
    fontSize: '16px',
  },
  profileContainer: {
    position: 'relative',
    display: 'inline-block',
  },
  profile: {
    padding: '10px',
    backgroundColor: colors.accent,
    borderRadius: '20px',
    cursor: 'pointer',
    color: '#fff',
    position: 'relative',
  },
  profileText: {
    fontSize: '16px',
  },
  dropdown: {
    position: 'absolute',
    top: '40px',
    right: '0',
    backgroundColor: '#fff',
    borderRadius: '10px',
    padding: '10px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    zIndex: 1000,
  },
  logoutButton: {
    backgroundColor: 'red',
    color: '#fff',
    padding: '5px 10px',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
  },
};

export default Navbar;
