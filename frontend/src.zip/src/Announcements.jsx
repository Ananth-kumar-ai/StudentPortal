import React from 'react';

const Announcements = () => {
    return (
        <div style={{ textAlign: 'center' }}>
            <h1>Announcements</h1>
            <p>There are no Announcements for now </p>
        </div>
    );
};

export default Announcements;